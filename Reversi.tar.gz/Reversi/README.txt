Example code in java for Reversi game:
To understand the game please visit: https://en.wikipedia.org/wiki/Reversi

Testcases contain the input files for the program just in case you want to run and check.
These test cases I had developed to check whether the program is working for every situation.

You will have to place input file from every folder into the floder that contains code, I had written a script to pick up
every file but cannot locate the script.

MakeFile is also included, please enter 'make agent' to compile and 'make run' to execute in the command line 
or you can use any IDE for it.

Entire code is in agent.java, I was supposed to code only using 1 file, so I haven't made sepearte files for seperate functions.

The code is for Reversi game logic, it contains 3 methods
1. Greedy
2. Max-Min Strategy
3. Max-Min with alpha-beta pruning

In case of any queries please contact me
email :- shahks@usc.edu
Phone # :- (323)347-8514
